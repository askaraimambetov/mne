#Variables which must be shared within the webapi

plug = None
static_dir = None
auth = None