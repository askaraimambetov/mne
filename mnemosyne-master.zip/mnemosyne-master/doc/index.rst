.. Mnemosyne documentation master file, created by
   sphinx-quickstart on Thu Jan  3 00:41:31 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Mnemosyne's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   Installation
   Normalization
   WebAPI



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

